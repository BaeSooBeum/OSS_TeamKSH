# D3 Chord Dependency Diagram

You can view this notebook by running a web server in this directory and
visiting it as a webpage. For example:

```sh
python -m SimpleHTTPServer
# Then, visit http://localhost:8000.
```

Or, use the [Notebook Runtime API](https://github.com/observablehq/notebook-runtime) to
integrate directly with d3-chord-dependency-diagram.js, which contains the notebook compiled as an
ES module.

*Exported from version 91 of [D3 Chord Dependency Diagram](https://beta.observablehq.com/@mbostock/d3-chord-dependency-diagram) on observablehq.com.*