# G2 - Basic Bar Chart

You can view this notebook by running a web server in this directory and
visiting it as a webpage. For example:

```sh
python -m SimpleHTTPServer
# Then, visit http://localhost:8000.
```

Or, use the [Notebook Runtime API](https://github.com/observablehq/notebook-runtime) to
integrate directly with g2-basic-bar-chart.js, which contains the notebook compiled as an
ES module.

*Exported from version 48 of [G2 - Basic Bar Chart](https://beta.observablehq.com/@jiazhewang/g2-basic-bar-chart) on observablehq.com.*